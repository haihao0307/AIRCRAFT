# Reference scope and byte status

The user supplied four Airfix reference crops and two B17 color/material photographs during the conversation.
The exact local image bytes are included in the separately verified local maximal handoff ZIP delivered in the same chat.

A binary transfer attempt into this GitHub handoff branch produced an invalid truncated archive. That invalid file is deliberately excluded from this GitHub-built ZIP and must not be used.

Airfix compressed-review copies recorded from the local maximal handoff:

- Airfix_bottom.jpg: 49,598 bytes, SHA256 561af9d11caf3d64f6a9b6c6726d5c6fd625fa3eaf39f8c1f423ea9b2c7ecc9b
- Airfix_port.jpg: 54,531 bytes, SHA256 dfe6f252896c405424fa8ce989938a0dde1acc7c2a4e85ce96ec7c9ede0af2a5
- Airfix_starboard.jpg: 29,271 bytes, SHA256 f110084f0a330a908de863f34babd661eabdbe08cb0c9be8c4cbc0ab97ca2ed8
- Airfix_top.jpg: 61,193 bytes, SHA256 a7e6ef0db73acb8a058cbb4365f0f703574fe1d9b6cf7c03e13e9aa4039a57d2
- combined local reference ZIP: 187,643 bytes, SHA256 582d72de56e9bbfb977bc3525a22696c9f4ef591f9372ad9ea11a18f1b492e64

B17 local reference copies:

- B17_colour_ref_1.jpg: 156,926 bytes, SHA256 cfc28da788225a980472783a94ab700543772282242007d07fc241da95a317f6
- B17_colour_ref_2.jpg: 176,000 bytes, SHA256 65abe809caf94e29dc378d37c3ce1c5b8d4d584c6a416b95bcd837ba56dedb04

Use each Airfix view independently for placement, size, orientation and paint-demarcation review. They do not prove that every B-24D detail applies to the target B-24J-25-CO. B17 photographs were supplied only for exterior color and material feeling. Do not transfer B17 structure, windows or marking placement to the B24.
