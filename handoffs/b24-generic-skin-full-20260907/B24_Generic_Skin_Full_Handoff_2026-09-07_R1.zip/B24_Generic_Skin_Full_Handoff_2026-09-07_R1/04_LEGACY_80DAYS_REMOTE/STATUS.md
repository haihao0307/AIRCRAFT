# Status

This directory preserves remote 80 DAYS research and material experiments only.
V2 was rejected. The early generated nose-art boards contained hallucinated windows, lettering, dice, shark eye, shark mouth and placement.
Do not use those outputs as historical truth. The generic B24 common master must be accepted before aircraft-specific nose art resumes.
