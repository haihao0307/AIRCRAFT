from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parents[1]
failed=[];count=0
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
    if not line.strip(): continue
    digest,rel=line.split('  ',1);p=root/rel
    if not p.exists(): failed.append((rel,'missing'));continue
    h=hashlib.sha256(p.read_bytes()).hexdigest();count+=1
    if h!=digest: failed.append((rel,'hash mismatch'))
print({'checked':count,'failed':failed})
sys.exit(bool(failed))
