from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os
root=Path(__file__).resolve().parents[1]/'01_CURRENT_REMOTE_SOURCE'
os.chdir(root)
print('Open http://127.0.0.1:8765/b24-generic-skin-closed-doors-r6.html')
ThreadingHTTPServer(('127.0.0.1',8765),SimpleHTTPRequestHandler).serve_forever()
